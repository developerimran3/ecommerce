<div class="order-success-page">

    <div class="success-card">
        <!-- Logo -->
        <div class="success-logo">
            <img src="<?php echo e(asset('assets/img/order-success.png')); ?>" alt="Congratulations">
        </div>
        <!-- Message -->
        <h3>
            আপনার অর্ডারটি আমাদের কাছে সফলভাবে পৌঁছেছে,
            <br>
            কিছুক্ষণের মধ্যে আমাদের একজন প্রতিনিধি আপনার নম্বরে কল করবেন।
        </h3>
        <!-- Order Details -->

        <h5 class="my-2">Your Order Details</h5>
        <div class="box">
            <table class="table table-bordered table-sm">
                <tr>
                    <td> Invoice ID <br>
                        <b> <?php echo e($order->invoice_no); ?></b>
                    </td>

                    <td> Date <br>
                        <b> <?php echo e($order->created_at->format('d-m-y')); ?></b>
                    </td>

                    <td> Phone <br>
                        <b> <?php echo e($order->phone); ?></b>
                    </td>

                    <td> Total <br>
                        <b>৳ <?php echo e($order->grand_total); ?></b>
                    </td>
                </tr>
                <tr>
                    <td colspan="4"> Payment Method <br>
                        <b> <?php echo e(ucfirst($order->payment_method)); ?></b>
                    </td>
                </tr>
            </table>
        </div>

        <p class="mt-3"> Pay with cash upon delivery </p>
        <!-- Product -->
        <div class="box">
            <h6> Order Delivery </h6>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th> Product </th>
                        <th> Total </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($item->product->name); ?>

                                , Qty: <?php echo e($item->qty); ?>

                                <br>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->color): ?>
                                    Color: <?php echo e($item->color?->name); ?>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <br>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->size): ?>
                                    Size: <?php echo e($item->size?->name); ?>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td> ৳ <?php echo e($item->subtotal); ?> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <tr>
                        <td class="text-right">
                            Net Total
                        </td>
                        <td>
                            <b style="color: #008e74"> ৳ <?php echo e($order->subtotal); ?></b>
                        </td>
                    </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->discount > 0): ?>
                        <tr>
                            <td class="text-right">
                                Discount
                            </td>
                            <td>
                                ৳ <?php echo e($order->discount); ?>

                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <tr>
                        <td class="text-right">
                            Shipping Cost
                        </td>
                        <td>
                            ৳ <?php echo e($order->shipping); ?>

                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">
                            <b>Grand Total</b>
                        </td>
                        <td>
                            <b>৳ <?php echo e($order->grand_total); ?></b>
                        </td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-bordered table-sm">
                <tr>
                    <td>
                        <h5 class="my-3">Billing Address</h5>
                        <?php echo e($order->name); ?> <br>
                        <?php echo e($order->phone); ?> <br>
                        <?php echo e($order->address); ?>

                    </td>
                </tr>
            </table>
        </div>

        <!-- Button -->
        <div class="action-btn">
            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-sm"> Go To Home </a>
            <a target="_blank" href="<?php echo e(route('customer.invoice.download', $order->id)); ?>"
                class="btn btn-success btn-sm"> <i class="fa fa-save"></i>
                Save PDF </a>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/livewire/frontend/order-success.blade.php ENDPATH**/ ?>