<section class="chheckout-section">
    <div class="container">
        <div class="row">
            <div class="col-sm-5 cus-order-2">
                <div class="checkout-shipping">
                    <div class="card">
                        <div class="card-header">
                            <h6>আপনার অর্ডারটি কনফার্ম করতে তথ্যগুলো পূরণ করে "অর্ডার করুন" বাটন এ ক্লিক করুন </h6>
                        </div>
                        <div class="card-body ">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group mb-3">
                                        <label class="form-check-label-checkout" for="name">আপনার নাম লিখুন
                                            *</label>
                                        <input type="text" id="name" class="form-control text-capitalize"
                                            wire:model="name" name="name">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group mb-3">
                                        <label class="form-check-label-checkout" for="email">আপনার ই-মেইল লিখুন
                                            *</label>
                                        <input type="email" id="email" class="form-control" wire:model="email"
                                            name="email">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                                <!-- col-end -->
                                <div class="col-sm-12">
                                    <div class="form-group mb-3">
                                        <label class="form-check-label-checkout" for="phone">মোবাইল নাম্বার দিন
                                            *</label>
                                        <input type="text" minlength="11" id="number" maxlength="11"
                                            pattern="0[0-9]+" class="form-control" name="phone" wire:model="phone">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                                <!-- col-end -->
                                <div class="col-sm-12">
                                    <div class="form-group mb-3">
                                        <label class="form-check-label-checkout" for="address">ঠিকানা লিখুন *</label>
                                        <input type="address" id="address" class="form-control" name="address"
                                            wire:model="address">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group mb-3">
                                        <label class="form-check-label-checkout" for="area"> ডেলিভারি এরিয়া নির্বাচন
                                            করুন </label>
                                        <select id="area" class="form-control" wire:model.live="area">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $shippingAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shippingArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($shippingArea->id); ?>">
                                                    <?php echo e($shippingArea->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="payment-methods">
                                    <div class="mb-3">
                                        <label class="form-check-label-checkout"> পেমেন্ট মেথড </label>
                                    </div>
                                    
                                    <div class="form-check p_cash mb-2">
                                        <input class="form-check-input" type="radio" id="cod"
                                            name="payment_method" value="cod" wire:model.live="payment_method">
                                        <label class="form-check-label" for="cod"> Cash On Delivery </label>
                                    </div>
                                    
                                    <div class="form-check p_bkash mb-2">
                                        <input class="form-check-input" type="radio" id="bkash"
                                            name="payment_method" value="bkash" wire:model.live="payment_method">
                                        <label class="form-check-label" for="bkash"> bKash </label>
                                    </div>
                                    
                                    <div class="form-check p_nagad mb-2">
                                        <input class="form-check-input" type="radio" id="nagad"
                                            name="payment_method" value="nagad" wire:model.live="payment_method">
                                        <label class="form-check-label" for="nagad"> Nagad </label>
                                    </div>
                                    
                                    <div class="form-check p_ssl mb-2">

                                        <input class="form-check-input" type="radio" id="sslcommerz"
                                            name="payment_method" value="sslcommerz" wire:model.live="payment_method">

                                        <label class="form-check-label" for="sslcommerz">
                                            Online Payment
                                        </label>

                                    </div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(in_array($payment_method, ['bkash', 'nagad'])): ?>
                                        <div class="form-group mt-3">
                                            <label class="form-check-label-checkout"> Transaction ID </label>

                                            <input type="text" class="form-control" wire:model="trx_id"
                                                placeholder="Enter Transaction ID">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['trx_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"> <?php echo e($message); ?> </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <button class="order_place" wire:click="placeOrder">অর্ডার করুন</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- col end -->
            <div class="col-sm-7 cust-order-1">
                <div class="cart_details table-responsive-sm">
                    <div class="card">
                        <div class="card-header">
                            <h6>অর্ডারের তথ্য</h6>
                        </div>

                        <div class="card-body cartlist">
                            <table class="cart_table table table-bordered table-striped text-center mb-0">
                                <thead>
                                    <tr>
                                        <th style="width:20%;">ডিলিট</th>
                                        <th style="width:40%;">প্রোডাক্ট</th>
                                        <th style="width:20%;">পরিমাণ</th>
                                        <th style="width:20%;">মূল্য</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cart && $cart->items->count()): ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="javascript:void(0)"
                                                        wire:click="removeItem(<?php echo e($item->id); ?>)"
                                                        class="text-danger">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </td>

                                                <td class="text-left">
                                                    <?php echo e(Str::limit($item->product->name, 20)); ?>

                                                </td>

                                                <td>
                                                    <div class="quantity-box">
                                                        <button
                                                            wire:click="decreaseQty(<?php echo e($item->id); ?>)">−</button>
                                                        <input type="text" value="<?php echo e($item->qty); ?>" readonly>
                                                        <button
                                                            wire:click="increaseQty(<?php echo e($item->id); ?>)">+</button>
                                                    </div>
                                                </td>

                                                <td>৳ <?php echo e(number_format($item->subtotal)); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </tbody>

                                <tfoot>
                                    <tr>
                                        <th colspan="3" class="text-end px-4">মোট</th>
                                        <td class="px-4">
                                            <span class="alinur">৳</span>
                                            <strong><?php echo e(number_format($subtotal ?? 0)); ?></strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th colspan="3" class="text-end px-4"> ডেলিভারি চার্জ </th>
                                        <td class="px-4">
                                            <span class="alinur">৳</span>
                                            <strong>
                                                <?php echo e(number_format($shipping ?? 0, 2)); ?>

                                            </strong>
                                        </td>
                                    </tr>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($discount > 0): ?>
                                        <tr>
                                            <th colspan="3" class="text-right px-4 text-success">
                                                Coupon Discount
                                            </th>
                                            <td class="px-4 text-success">
                                                - ৳ <?php echo e(number_format($discount, 2)); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <tr>
                                        <th colspan="3" class="text-end px-4"> সর্বমোট </th>
                                        <td class="px-4">
                                            <span class="alinur">৳</span>
                                            <strong>
                                                <?php echo e(number_format($grandTotal ?? 0, 2)); ?>

                                            </strong>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cart && $cart->items->count()): ?>
                            <div class="card-footer">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$coupon): ?>
                                    <form id="coupon_form">
                                        <div class="form-group mb-2">
                                            <label for="coupon_code">Have a coupon?</label>
                                            <input type="text" id="coupon_code"
                                                class="form-control"wire:model="coupon_code"
                                                placeholder="Enter coupon code">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['coupon_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"> <?php echo e($message); ?> </small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                        <button type="button" wire:click="applyCoupon"
                                            class="btn btn-primary btn-sm"> Apply Coupon
                                        </button>
                                        <div id="coupon-message" class="mt-2"></div>
                                    </form>
                                <?php else: ?>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong> <?php echo e($coupon->code); ?> </strong>
                                            <br>
                                            <small class="text-success"> Coupon applied </small>
                                        </div>
                                        <button type="button" class="btn btn-danger btn-sm"
                                            wire:click="removeCoupon"> Remove
                                        </button>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- col end -->
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/livewire/frontend/checkout-page.blade.php ENDPATH**/ ?>