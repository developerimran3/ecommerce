<header id="navbar_top">
    <div class="mobile-header sticky">
        <div class="mobile-logo">
            <div class="menu-bar">
                <a class="toggle">
                    <i class="fa-solid fa-bars"></i>
                </a>
            </div>
            <div class="menu-logo">
                <a href="<?php echo e(route('home')); ?>" wire:navigate><img src="<?php echo e(asset('assets/img/home-logo.jpg')); ?>"
                        alt=""></a>
            </div>
            <div class="menu-bag">
                <p class="margin-shopping">
                    <i class="fa-solid fa-cart-shopping"></i>
                    <span class="mobilecart-qty">0</span>
                </p>
            </div>
        </div>
    </div>

    <div class="mobile-search">
        <form action="" wire:submit.prevent="search">
            <input type="text" placeholder="Search Product ... " value="" class="msearch_keyword msearch_click"
                name="keyword">
            <button>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    class="feather feather-search">
                </svg>
            </button>
        </form>
        <div class="search_result"></div>
    </div>

    <div class="main-header">
        <!-- header to end -->
        <div class="logo-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="logo-header">
                            <div class="main-logo">
                                <a href="<?php echo e(route('home')); ?>" wire:navigate><img
                                        src="<?php echo e(asset('assets/img/home-logo.jpg')); ?>" alt=""></a>
                            </div>
                            <div class="main-search">
                                <form action="#">
                                    <input type="text" placeholder="Search Product..."
                                        class="search_keyword search_click" name="keyword">
                                    <button>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-search">
                                            <circle cx="11" cy="11" r="8"></circle>
                                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                        </svg>
                                    </button>
                                </form>
                                <div class="search_result"></div>
                            </div>
                            <div class="header-list-items">
                                <ul>
                                    <li class="track_btn">
                                        <a href="<?php echo e(route('order.track')); ?>" wire:navigate> <i
                                                class="fa fa-truck"></i>Track Order</a>
                                    </li>
                                    <li class="cart-dialog" id="cart-qty">
                                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.cart-count', []);

$__key = null;

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2339591832-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key);

echo $__html;

unset($__html);
unset($__key);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="menu-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="catagory_menu">
                            <div class="mobile-menu">
                                <ul class="heder__category">
                                    <div>
                                        <li class="all__category__list">
                                            <a href="#">ALL CATEGORIES <i class="fa-solid fa-list"></i>
                                            </a>
                                            <div></div>
                                        </li>
                                    </div>


                                    <div>
                                        <li><a href="<?php echo e(route('home')); ?>" wire:navigate>Home</a></li>
                                    </div>
                                    <div>
                                        <li><a href="#" wire:navigate>Offers</a></li>
                                    </div>

                                    <div class="contact__menu">
                                        <li><a href="#" wire:navigate>Contact</a></li>
                                    </div>
                                    <div class="right__menu__top">
                                        <li class="for_order">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::check()): ?>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()->role == 'Customer'): ?>
                                                    <a href="<?php echo e(route('account')); ?>" wire:navigate>
                                                        <i class="fa-regular fa-user"></i>
                                                        <?php echo e(ucwords(Str::limit(Auth::user()->name, 10))); ?>

                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('users.profile')); ?>">
                                                        <i class="fa-regular fa-user"></i>
                                                        <?php echo e(Str::limit(Auth::user()->name, 10)); ?>

                                                    </a>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('customer.login')); ?>" wire:navigate>
                                                    <i class="fa-regular fa-user"></i>
                                                    Login / Sign Up
                                                </a>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </li>
                                    </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- main-header end -->
</header>
<script>
    $(document).ready(function() {

        $('.toggle').click(function() {

            $('.mobile-menu').toggleClass('active');

        });


    });
</script>
<?php /**PATH C:\xampp\htdocs\Laravel Livewire\ecommerce\resources\views/partials/frontend-navbar.blade.php ENDPATH**/ ?>