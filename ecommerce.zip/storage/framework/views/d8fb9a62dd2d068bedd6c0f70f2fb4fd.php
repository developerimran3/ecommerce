<div class="cart-wrapper ">
    <a href="<?php echo e(route('checkout')); ?>" wire:navigate>
        <p class="margin-shopping">
            <i class="fa-solid fa-cart-shopping"></i>
            <span> <?php echo e($count ?? 0); ?></span>
        </p>
    </a>

    <!-- Mini Cart -->
    <div class="mini-cart">

        <table class="table ">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cart && $cart->items->count()): ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e(Str::limit($item->product->name, 20)); ?> </td>
                            <td> <?php echo e($item->qty); ?> </td>
                            <td> ৳<?php echo e(number_format($item->subtotal)); ?> </td>
                            <td><a href="javascript:void(0)" wire:click="removeItem(<?php echo e($item->id); ?>)"
                                    class="text-danger">
                                    <i class="fa fa-times"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
        <div class="mini-cart-footer">
            <p class="text-center"><strong> সর্বমোট :
                    ৳<?php echo e(number_format($cart ? $cart->items->sum('subtotal') : 0, 2)); ?></strong></p>
            <a href="<?php echo e(route('checkout')); ?>" wire:navigate> অর্ডার করুন </a>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel Livewire\ecommerce\resources\views/livewire/frontend/cart-count.blade.php ENDPATH**/ ?>