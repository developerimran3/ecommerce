<aside class="sidebar" id="sidebar">

    
    <div class="logo d-flex align-items-center">
        <div class="logo-icon">
            <img src="<?php echo e(asset('assets/img/dashboard-logo.jpg')); ?>" alt="">
        </div>
    </div>

    <div class="p-4">
        <ul class="nav flex-column">
            
            <li class="nav-item">
                <a href="<?php echo e(route('admin.dashboard')); ?>" wire:navigate.hover
                    class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">

                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>

                </a>
            </li>
            
            <?php
                $ordersActive = request()->routeIs('admin.orders*') || request()->routeIs('admin.payment*');
            ?>

            <li class="nav-item">

                <a href="javascript:void(0)" class="nav-link menu-toggle <?php echo e($ordersActive ? 'active' : ''); ?>">

                    <i class="fas fa-shopping-cart"></i>

                    <span class="flex-grow-1">
                        Orders
                    </span>

                    <i class="fas fa-chevron-down arrow <?php echo e($ordersActive ? 'rotate' : ''); ?>"></i>

                </a>

                <ul class="submenu <?php echo e($ordersActive ? 'open' : ''); ?>">

                    
                    <li>
                        <a href="<?php echo e(route('admin.orders')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.orders') ? 'active' : ''); ?>">

                            <i class="fas fa-list"></i>
                            <span>All Orders</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.orders.pending')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.orders.pending') ? 'active' : ''); ?>">

                            <i class="fas fa-clock"></i>
                            <span>Pending Orders</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.orders.completed')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.orders.completed') ? 'active' : ''); ?>">

                            <i class="fas fa-check-circle"></i>
                            <span>Completed Orders</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.orders.cancelled')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.orders.cancelled') ? 'active' : ''); ?>">

                            <i class="fas fa-times-circle"></i>
                            <span>Cancelled Orders</span>

                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(route('admin.payment')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.payment*') ? 'active' : ''); ?>">
                            <i class="fas fa-credit-card"></i>
                            <span>Payment</span>

                        </a>
                    </li>

                </ul>
            </li>
            
            <?php
                $productsActive =
                    request()->routeIs('admin.products*') ||
                    request()->routeIs('admin.categories*') ||
                    request()->routeIs('admin.brands*') ||
                    request()->routeIs('admin.coupon*') ||
                    request()->routeIs('admin.shipping*') ||
                    request()->routeIs('admin.products.color') ||
                    request()->routeIs('admin.products.size');
            ?>

            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link menu-toggle <?php echo e($productsActive ? 'active' : ''); ?>">
                    <i class="fas fa-box"></i>
                    <span class="flex-grow-1"> Products </span>
                    <i class="fas fa-chevron-down arrow <?php echo e($productsActive ? 'rotate' : ''); ?>"></i>
                </a>
                <ul class="submenu <?php echo e($productsActive ? 'open' : ''); ?>">
                    
                    <li>
                        <a href="<?php echo e(route('admin.products')); ?>"
                            class="<?php echo e(request()->routeIs('admin.products*') ? 'active' : ''); ?>">
                            <i class="fas fa-box-open"></i>
                            <span>Products Manage</span>
                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.categories')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.categories*') ? 'active' : ''); ?>">
                            <i class="fas fa-layer-group"></i>
                            <span>Categories</span>
                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.brands')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.brands*') ? 'active' : ''); ?>">
                            <i class="fas fa-copyright"></i>
                            <span>Brands</span>
                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.products.color')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.products.color') ? 'active' : ''); ?>">
                            <i class="fas fa-palette"></i>
                            <span>Colors</span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(route('admin.products.size')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.products.size') ? 'active' : ''); ?>">
                            <i class="fas fa-ruler-combined"></i>
                            <span>Sizes</span>
                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.coupon')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.coupon*') ? 'active' : ''); ?>">
                            <i class="fas fa-ticket-alt"></i>
                            <span>Coupons</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.shipping')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.shipping*') ? 'active' : ''); ?>">

                            <i class="fas fa-truck"></i>
                            <span>Shipping Charge</span>

                        </a>
                    </li>
                </ul>
            </li>

            
            <?php
                $reviewsActive = request()->routeIs('admin.reviews*') || request()->routeIs('admin.review*');
            ?>

            <li class="nav-item">

                <a href="javascript:void(0)" class="nav-link menu-toggle <?php echo e($reviewsActive ? 'active' : ''); ?>">

                    <i class="fas fa-star"></i>

                    <span class="flex-grow-1">
                        Reviews
                    </span>

                    <i class="fas fa-chevron-down arrow <?php echo e($reviewsActive ? 'rotate' : ''); ?>"></i>

                </a>

                <ul class="submenu <?php echo e($reviewsActive ? 'open' : ''); ?>">

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.reviews.pending') ? 'active' : ''); ?>">

                            <i class="fas fa-hourglass-half"></i>
                            <span>Pending Reviews</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.reviews.create') ? 'active' : ''); ?>">

                            <i class="fas fa-plus-circle"></i>
                            <span>Create Review</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.reviews') ? 'active' : ''); ?>">

                            <i class="fas fa-comments"></i>
                            <span>All Reviews</span>

                        </a>
                    </li>

                </ul>
            </li>


            
            
            
            <?php
                $landingActive = request()->routeIs('admin.landing*') || request()->routeIs('admin.campaign*');
            ?>

            <li class="nav-item">

                <a href="javascript:void(0)" class="nav-link menu-toggle <?php echo e($landingActive ? 'active' : ''); ?>">

                    <i class="fas fa-window-maximize"></i>

                    <span class="flex-grow-1">
                        Landing Page
                    </span>

                    <i class="fas fa-chevron-down arrow <?php echo e($landingActive ? 'rotate' : ''); ?>"></i>

                </a>

                <ul class="submenu <?php echo e($landingActive ? 'open' : ''); ?>">

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.landing.create') ? 'active' : ''); ?>">

                            <i class="fas fa-plus-square"></i>
                            <span>Create</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.campaign*') ? 'active' : ''); ?>">

                            <i class="fas fa-bullhorn"></i>
                            <span>Campaign</span>

                        </a>
                    </li>

                </ul>
            </li>


            
            
            
            <?php
                $usersActive =
                    request()->routeIs('admin.users*') ||
                    request()->routeIs('users.profile*') ||
                    request()->routeIs('admin.customers.manage') ||
                    request()->routeIs('admin.role-permissions');
            ?>

            <li class="nav-item">
                <a href="javascript:void(0)" class="nav-link menu-toggle <?php echo e($usersActive ? 'active' : ''); ?>">
                    <i class="fas fa-users"></i>
                    <span class="flex-grow-1"> Users </span>
                    <i class="fas fa-chevron-down arrow <?php echo e($usersActive ? 'rotate' : ''); ?>"></i>
                </a>
                <ul class="submenu <?php echo e($usersActive ? 'open' : ''); ?>">

                    
                    <li>
                        <a href="<?php echo e(route('admin.users')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.users*') ? 'active' : ''); ?>">
                            <i class="fas fa-user"></i>
                            <span>User</span>
                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('users.profile')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('users.profile*') ? 'active' : ''); ?>">
                            <i class="fas fa-user-circle"></i>
                            <span>Profile</span>
                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.customers.manage')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.customers.manage') ? 'active' : ''); ?>">
                            <i class="fas fa-user-friends"></i>
                            <span>Customers</span>
                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.role-permissions')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.role-permissions') ? 'active' : ''); ?>">
                            <i class="fas fa-key"></i>
                            <span>Permission</span>
                        </a>
                    </li>
                </ul>
            </li>


            
            
            
            <?php
                $settingsActive =
                    request()->routeIs('admin.settings*') ||
                    request()->routeIs('admin.smpt.server*') ||
                    request()->routeIs('admin.smtp.server*');
            ?>

            <li class="nav-item">

                <a href="javascript:void(0)" class="nav-link menu-toggle <?php echo e($settingsActive ? 'active' : ''); ?>">

                    <i class="fas fa-cog"></i>

                    <span class="flex-grow-1">
                        Site Setting
                    </span>

                    <i class="fas fa-chevron-down arrow <?php echo e($settingsActive ? 'rotate' : ''); ?>"></i>

                </a>

                <ul class="submenu <?php echo e($settingsActive ? 'open' : ''); ?>">

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.settings.general*') ? 'active' : ''); ?>">

                            <i class="fas fa-sliders-h"></i>
                            <span>General Setting</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.settings.social*') ? 'active' : ''); ?>">

                            <i class="fas fa-share-alt"></i>
                            <span>Social Media</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.settings.contact*') ? 'active' : ''); ?>">

                            <i class="fas fa-address-book"></i>
                            <span>Contact</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.settings.pages*') ? 'active' : ''); ?>">

                            <i class="fas fa-file-alt"></i>
                            <span>Create Page</span>

                        </a>
                    </li>
                </ul>
            </li>


            
            
            
            <?php
                $apiActive =
                    request()->routeIs('admin.api*') ||
                    request()->routeIs('admin.courier.setting') ||
                    request()->routeIs('admin.smtp.settings') ||
                    request()->routeIs('admin.gateway*') ||
                    request()->routeIs('admin.sms*');
            ?>

            <li class="nav-item">

                <a href="javascript:void(0)" class="nav-link menu-toggle <?php echo e($apiActive ? 'active' : ''); ?>">

                    <i class="fas fa-plug"></i>

                    <span class="flex-grow-1">
                        API Integration
                    </span>

                    <i class="fas fa-chevron-down arrow <?php echo e($apiActive ? 'rotate' : ''); ?>"></i>

                </a>

                <ul class="submenu <?php echo e($apiActive ? 'open' : ''); ?>">

                    
                    <li>
                        <a href="<?php echo e(route('admin.courier.setting')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.courier.setting') ? 'active' : ''); ?>">

                            <i class="fas fa-shipping-fast"></i>
                            <span>Couriers API</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.smtp.settings')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.smtp.settings') ? 'active' : ''); ?>">

                            <i class="fas fa-envelope"></i>
                            <span>Mail SMTP</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.gateway*') ? 'active' : ''); ?>">

                            <i class="fas fa-credit-card"></i>
                            <span>Payment Gateway</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.sms*') ? 'active' : ''); ?>">

                            <i class="fas fa-sms"></i>
                            <span>SMS Gateway</span>

                        </a>
                    </li>

                </ul>
            </li>


            
            
            
            <?php
                $bannerActive = request()->routeIs('admin.banner.categories') || request()->routeIs('admin.banner');
            ?>

            <li class="nav-item">

                <a href="javascript:void(0)" class="nav-link menu-toggle <?php echo e($bannerActive ? 'active' : ''); ?>">

                    <i class="fas fa-images"></i>

                    <span class="flex-grow-1">
                        Banner & Ads
                    </span>

                    <i class="fas fa-chevron-down arrow <?php echo e($bannerActive ? 'rotate' : ''); ?>"></i>

                </a>

                <ul class="submenu <?php echo e($bannerActive ? 'open' : ''); ?>">

                    
                    <li>
                        <a href="<?php echo e(route('admin.banner.categories')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.banner.categories') ? 'active' : ''); ?>">

                            <i class="fas fa-folder"></i>
                            <span>Banner Categories</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(route('admin.banner')); ?>" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.banner') ? 'active' : ''); ?>">

                            <i class="fas fa-ad"></i>
                            <span>Banners & Ads</span>

                        </a>
                    </li>

                </ul>
            </li>


            
            
            
            <?php
                $reportsActive =
                    request()->routeIs('admin.reports*') ||
                    request()->routeIs('admin.stock.report*') ||
                    request()->routeIs('admin.ip*');
            ?>

            <li class="nav-item">

                <a href="javascript:void(0)" class="nav-link menu-toggle <?php echo e($reportsActive ? 'active' : ''); ?>">

                    <i class="fas fa-chart-bar"></i>

                    <span class="flex-grow-1">
                        Reports
                    </span>

                    <i class="fas fa-chevron-down arrow <?php echo e($reportsActive ? 'rotate' : ''); ?>"></i>

                </a>

                <ul class="submenu <?php echo e($reportsActive ? 'open' : ''); ?>">

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.stock.report*') ? 'active' : ''); ?>">

                            <i class="fas fa-boxes"></i>
                            <span>Stock Report</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.reports.sales*') ? 'active' : ''); ?>">

                            <i class="fas fa-chart-line"></i>
                            <span>Sales Report</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.reports.orders*') ? 'active' : ''); ?>">

                            <i class="fas fa-file-invoice"></i>
                            <span>Order Report</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.reports.customers*') ? 'active' : ''); ?>">

                            <i class="fas fa-users"></i>
                            <span>Customer Report</span>

                        </a>
                    </li>

                    
                    <li>
                        <a href="#" wire:navigate.hover
                            class="<?php echo e(request()->routeIs('admin.ip*') ? 'active' : ''); ?>">

                            <i class="fas fa-globe"></i>
                            <span>IP</span>

                        </a>
                    </li>

                </ul>
            </li>


            
            
            
            <?php
                $mediaActive = request()->routeIs('admin.media*');
            ?>

            <li class="nav-item">

                <a href="<?php echo e(route('admin.media')); ?>" wire:navigate.hover
                    class="nav-link <?php echo e($mediaActive ? 'active' : ''); ?>">

                    <i class="fas fa-photo-video"></i>
                    <span>Media</span>

                </a>

            </li>

        </ul>
    </div>

</aside>
<?php /**PATH C:\xampp\htdocs\Laravel Livewire\ecommerce\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>