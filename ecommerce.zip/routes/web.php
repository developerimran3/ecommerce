<?php

use App\Http\Controllers\InvoiceController;
use App\Livewire\Admin\Banner\BannerCategory;
use App\Livewire\Admin\Banner\BannerIndex;
use App\Livewire\Admin\Brand\Index as BrandIndex;
use App\Livewire\Admin\Category\Index as CategoryIndex;
use App\Livewire\Admin\Coupon\Index as CouponIndex;
use App\Livewire\Admin\Dashboard;
use App\Livewire\Admin\Media\Index as MediaIndex;
use App\Livewire\Admin\Order\Index as OrderIndex;
use App\Livewire\Admin\Payment\Index as PaymentIndex;
use App\Livewire\Admin\Product\Color;
use App\Livewire\Admin\Product\Index as ProductIndex;
use App\Livewire\Admin\Product\Size;
use App\Livewire\Admin\Profile\Index as ProfileIndex;
use App\Livewire\Admin\RolePermission\Index as Permission;
use App\Livewire\Admin\Shipping\ShippingAreaIndex;
use App\Livewire\Admin\SiteSetting\CourierSetting;
use App\Livewire\Admin\SiteSetting\SmtpSetting;
use App\Livewire\Admin\User\CustomerManage;
use App\Livewire\Admin\User\CustomerView;
use App\Livewire\Admin\User\Index as UserIndex;
use App\Livewire\Auth\Admin\ForgotPassword as AdminForgotPassword;
use App\Livewire\Auth\Admin\Login as AdminLogin;
use App\Livewire\Auth\Admin\Register as AdminRegister;
use App\Livewire\Auth\Admin\ResetPassword as AdminResetPassword;
use App\Livewire\Auth\Customer\ForgotPassword as CustomerForgotPassword;
use App\Livewire\Auth\Customer\Login as CustomerLogin;
use App\Livewire\Auth\Customer\Register as CustomerRegister;
use App\Livewire\Auth\Customer\ResetPassword as CustomerResetPassword;
use App\Livewire\Customer\Account as MyAccount;
use App\Livewire\Customer\Order as MyOrders;
use App\Livewire\Customer\PasswordChange;
use App\Livewire\Customer\Profile as CustomerProfile;
use App\Livewire\Frontend\Category\ProductCategory;
use App\Livewire\Frontend\CheckoutPage;
use App\Livewire\Frontend\Home;
use App\Livewire\Frontend\Offer\HotDalesProduct;
use App\Livewire\Frontend\OrderSuccess;
use App\Livewire\Frontend\OrderTrack;
use App\Livewire\Frontend\ProductDetails;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::middleware('auth')->get('/create-storage-link', function () {

    Artisan::call('storage:link');

    return response()->json([
        'success' => true,
        'message' => 'Storage link created successfully.',
        'output' => Artisan::output(),
    ]);
});
//PUBLIC ROUTE
Route::get('/', Home::class)->name('home');

Route::get('/product/{slug}', ProductDetails::class)
    ->name('product.details');

Route::get('/checkout', CheckoutPage::class)
    ->name('checkout');

Route::get('/order-track', OrderTrack::class)
    ->name('order.track');


Route::get('/category/{slug}', ProductCategory::class)
    ->name('category.products');

Route::get('/hot-dales', HotDalesProduct::class)
    ->name('hot.dales.products');


Route::middleware('guest')->group(function () {
    //ADMIN GUEST ROUTES
    Route::get('/admin/login', AdminLogin::class)
        ->name('admin.login');

    Route::get('/admin/register', AdminRegister::class)
        ->name('admin.register');

    Route::get('/admin/forgot-password', AdminForgotPassword::class)
        ->name('admin.forgot.password');

    Route::get('/admin/reset-password/{token}', AdminResetPassword::class)
        ->name('admin.reset.password');

    //CUSTOMER GUEST ROUTES
    Route::get('/customer/login', CustomerLogin::class)
        ->name('customer.login');

    Route::get('/customer/register', CustomerRegister::class)
        ->name('customer.register');

    Route::get('/customer/forgot-password', CustomerForgotPassword::class)
        ->name('customer.forgot.password');

    Route::get('/customer/reset-password/{token}', CustomerResetPassword::class)
        ->name('customer.reset.password');
});


/*
|--------------------------------------------------------------------------
| CUSTOMER PROTECTED ROUTES
|--------------------------------------------------------------------------
*/

Route::prefix('customer')->middleware(['auth', 'active', 'customer',])->group(function () {

    Route::get('/my-account', MyAccount::class)
        ->name('account');

    Route::get('/my-orders', MyOrders::class)
        ->name('my.orders');

    Route::get('/profile', CustomerProfile::class)
        ->name('customer.profile');

    Route::get('/change-password', PasswordChange::class)
        ->name('customer.password');

    Route::get('/order-success/{order}', OrderSuccess::class)
        ->name('order.success');

    Route::get('/invoice/download/{id}', [InvoiceController::class, 'download'])
        ->name('customer.invoice.download');


    Route::get('/logout', function () {
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();
        return redirect()->route('home');
    })->name('customer.logout');
});


/*
|--------------------------------------------------------------------------
| ADMIN PROTECTED ROUTES
|--------------------------------------------------------------------------
*/

Route::prefix('admin')->middleware(['auth', 'active', 'admin',])->group(function () {

    Route::get('/dashboard', Dashboard::class)
        ->name('admin.dashboard');

    // products
    Route::get('/products', ProductIndex::class)
        ->middleware('permission:products.view')
        ->name('admin.products');

    Route::get('/products/categories', CategoryIndex::class)
        ->middleware('permission:categories.view')
        ->name('admin.categories');

    Route::get('/products/brands', BrandIndex::class)
        ->middleware('permission:brands.view')
        ->name('admin.brands');

    Route::get('/products/shipping-areas', ShippingAreaIndex::class)
        ->middleware('permission:shipping.view')
        ->name('admin.shipping');

    Route::get('/products/size', Size::class)
        ->middleware('permission:sizes.view')
        ->name('admin.products.size');

    Route::get('/products/color', Color::class)
        ->middleware('permission:colors.view')
        ->name('admin.products.color');

    Route::get('/products/coupon', CouponIndex::class)
        ->middleware('permission:coupons.view')
        ->name('admin.coupon');

    // Orders
    Route::get('/orders', OrderIndex::class)
        ->middleware('permission:orders.view')
        ->name('admin.orders');

    Route::get('/orders/payments', PaymentIndex::class)
        ->middleware('permission:payments.view')
        ->name('admin.payment');

    Route::get('/orders/invoice/download/{id}', [InvoiceController::class, 'download'])
        ->middleware('permission:invoices.view')
        ->name('admin.invoice.download');

    // users Profile
    Route::get('/users', UserIndex::class)
        ->middleware('permission:users.view')
        ->name('admin.users');

    Route::get('/users/profile', ProfileIndex::class)
        ->name('users.profile');

    Route::get('/customers/manage', CustomerManage::class)
        ->middleware('permission:customers.view')
        ->name('admin.customers.manage');

    Route::get('/customer/profile/{id}', CustomerView::class)
        ->middleware('permission:customers.view')
        ->name('admin.customer.view');

    Route::get('/users/role-permissions', Permission::class)
        ->middleware('role:Administrator')
        ->name('admin.role-permissions');

    // review
    Route::get('/reviews', UserIndex::class)
        ->middleware('permission:reviews.view')
        ->name('admin.reviews');

    // API Int setting
    Route::get('/courier-setting', CourierSetting::class)
        ->middleware('permission:couriers.view')
        ->name('admin.courier.setting');

    Route::get('/smtp-settings', SmtpSetting::class)
        ->middleware('permission:smtp.view')
        ->name('admin.smtp.settings');

    // banner And Ads
    Route::get('/banner/categories', BannerCategory::class)
        ->middleware('permission:banners_categories.view')
        ->name('admin.banner.categories');

    Route::get('/banner', BannerIndex::class)
        ->middleware('permission:banners.view')
        ->name('admin.banner');

    // media
    Route::get('/media', MediaIndex::class)
        ->middleware('permission:media.view')
        ->name('admin.media');

    // Log Out
    Route::get('/logout', function () {
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();
        return redirect()->route('admin.login');
    })->name('admin.logout');
});
