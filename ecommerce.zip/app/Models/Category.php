<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = [
        'name',
        'slug',
        'image',
        'status',
        'front_view',
    ];

    public function products()
    {
        return $this->hasMany(Product::class);
    }
}
